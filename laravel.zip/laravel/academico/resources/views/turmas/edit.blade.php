@extends('layout.principal')

@section('conteudo')

        <h1>Editar turma</h1>

        <form method="post" action="/turmas/{{ $turma->id }}">

          {{ method_field('PATCH') }}
          {{ csrf_field() }}

          <div class="form-group">
              <label for="nome">Nome</label>
              <input type="text" class="form-control" name="nome" value="{{$turma->nome}}" />
          </div>

          <div class="form-group">
              <label for="disciplina">Disciplina</label>
              {{ Form::select('disciplina_id', $disciplinas, $turma->disciplina_id, ["class"=>"form-control required", "id"=>"disciplina_id", "name"=>"disciplina_id"]) }}
          </div>

          <input type="submit" class="btn btn-primary" value="Salvar"/>

          <a href="/turmas" class="btn btn-primary">Voltar</a>

@endsection
