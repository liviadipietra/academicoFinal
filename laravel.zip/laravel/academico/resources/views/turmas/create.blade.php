@extends('layout.principal')

@section('conteudo')

        <h1>Inserir turma</h1>

        <form method="post" action="/turmas">

          {{ csrf_field() }}

          <div class="form-group">
              <label for="nome">Nome</label>
              <input type="text" class="form-control" name="nome" />
          </div>

          <div class="form-group">
              <label for="disciplina">Disciplina</label>
              {{ Form::select('disciplina_id', $disciplinas, old('disciplina_id'), ["class"=>"form-control required", "id"=>"disciplina_id", "name"=>"disciplina_id"]) }}
          </div>



          <input type="submit" class="btn btn-primary" value="Salvar"/>

          <a href="/disciplinas" class="btn btn-primary">Voltar</a>

@endsection
