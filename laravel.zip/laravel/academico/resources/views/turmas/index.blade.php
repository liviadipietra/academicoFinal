@extends('layout.principal')

@section('conteudo')

        <h1>Turmas</h1>

        @if(Session::has('nome'))
          <h2>{{ Session::get('nome') }}</h2>
        @endif

  <a href="/turmas/create" class="btn btn-primary">Inserir</a>

  <table class="table table-striped">
    <thead>
      <tr>
        <th>Nome</th>
        <th>Disciplina</th>
      </tr>
    </thead>
    <tbody>
        @foreach($turmas as $d)

          <tr>

            <td><a href="/turmas/{{ $d->id }}">{{ $d->nome }}</a></td>
            <td>{{ $d->disciplina->nome}}</td>

          </tr>
        @endforeach
      </tbody>
  </table>

@endsection
