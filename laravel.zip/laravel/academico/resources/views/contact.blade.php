@extends('layout.principal')

@section('conteudo')

  <h2> Contato:</h2>
  <p>Ligue para (31) 9999-9999</p>

@endsection
