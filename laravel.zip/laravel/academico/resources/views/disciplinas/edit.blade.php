@extends('layout.principal')

@section('conteudo')

        <h1>Editar disciplina</h1>

        <form method="post" action="/disciplinas/{{ $disciplina->id }}">

          {{ method_field('PATCH') }}
          {{ csrf_field() }}

          <div class="form-group">
              <label for="nome">Nome</label>
              <input type="text" class="form-control" name="nome" value="{{$disciplina->nome}}" />
          </div>

          <div class="form-group">
              <label for="codigo">Código</label>
              <input type="text" class="form-control" name="codigo" value="{{$disciplina->codigo}}" />
          </div>

          <div class="form-group">
              <label for="carga">Carga Horária</label>
              <input type="text" class="form-control" name="carga" value="{{$disciplina->carga}}" />
          </div>

          <input type="submit" class="btn btn-primary" value="Salvar"/>

          <a href="/disciplinas" class="btn btn-primary">Voltar</a>

@endsection
