@extends('layout.principal')

@section('conteudo')

        <h1>Cidades</h1>

        @if(Session::has('nome'))
          <h2>{{ Session::get('nome') }}</h2>
        @endif

  <a href="/cidades/create" class="btn btn-primary">Inserir</a>

  <table class="table table-striped">
    <thead>
      <tr>
        <th>Nome</th>
        <th>Estado</th>
      </tr>
    </thead>
    <tbody>
        @foreach($cidades as $d)

          <tr>

            <td><a href="/cidades/{{ $d->id }}">{{ $d->nome }}</a></td>
            <td>{{ $d->estado->sigla}}</td>

          </tr>
        @endforeach
      </tbody>
  </table>

@endsection
