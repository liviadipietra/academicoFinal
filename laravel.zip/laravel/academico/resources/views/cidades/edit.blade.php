@extends('layout.principal')

@section('conteudo')

        <h1>Editar cidade</h1>

        <form method="post" action="/cidades/{{ $cidade->id }}">

          {{ method_field('PATCH') }}
          {{ csrf_field() }}

          <div class="form-group">
              <label for="nome">Nome</label>
              <input type="text" class="form-control" name="nome" value="{{$cidade->nome}}" />
          </div>

          <div class="form-group">
              <label for="estado">Estado</label>
              {{ Form::select('estado_id', $estados, $cidade->estado_id, ["class"=>"form-control required", "id"=>"estado_id", "name"=>"estado_id"]) }}
          </div>

          <input type="submit" class="btn btn-primary" value="Salvar"/>

          <a href="/cidades" class="btn btn-primary">Voltar</a>

@endsection
