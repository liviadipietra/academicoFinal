@extends('layout.principal')

@section('conteudo')

  <h2> Seja bem-vindo(a) ao Sistema Acadêmico!</h2>
  <p>Acesse as opções pelo menu lateral.</p>

@endsection
