@extends('layout.principal')

@section('conteudo')

        <h1>Editar estado</h1>

        <form method="post" action="/estados/{{ $estado->id }}">

          {{ method_field('PATCH') }}
          {{ csrf_field() }}

          <div class="form-group">
              <label for="nome">Nome</label>
              <input type="text" class="form-control" name="nome" value="{{$estado->nome}}" />
          </div>

          <div class="form-group">
              <label for="sigla">Sigla</label>
              <input type="text" class="form-control" name="sigla" value="{{$estado->sigla}}" />
          </div>

          <input type="submit" class="btn btn-primary" value="Salvar"/>

          <a href="/estados" class="btn btn-primary">Voltar</a>

@endsection
