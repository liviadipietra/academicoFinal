@extends('layout.principal')

@section('conteudo')

        <h1>Estados</h1>

        @if(Session::has('nome'))
          <h2>{{ Session::get('nome') }}</h2>
        @endif

  <a href="/estados/create" class="btn btn-primary">Inserir</a>

  <table class="table table-striped">
    <thead>
      <tr>
        <th>Nome</th>
        <th>Sigla</th>
      </tr>
    </thead>
    <tbody>
        @foreach($estados as $d)

          <tr>

            <td><a href="/estados/{{ $d->id }}">{{ $d->nome }}</a></td>
            <td>{{ $d->sigla}}</td>

          </tr>
        @endforeach
      </tbody>
  </table>

@endsection
