@extends('layout.principal')

@section('conteudo')

  <h2>Sobre o Sistema Acadêmico:</h2>
  <br><br><p>Sistema para controle acadêmico.</p>

@endsection
