@extends('layout.principal')

@section('conteudo')

        <h1>Editar Aluno</h1>

        <form method="post" action="/alunos/{{ $aluno->id }}">

          {{ method_field('PATCH') }}
          {{ csrf_field() }}

          <div class="form-group">
              <label for="nome">Nome</label>
              <input type="text" class="form-control" name="nome" value="{{ $aluno->nome }}" />
          </div>

          <div class="form-group">
              <label for="nome">Rua</label>
              <input type="text" class="form-control" name="rua" value="{{ $aluno->rua }}" />
          </div>

          <div class="form-group">
              <label for="nome">Número</label>
              <input type="number" class="form-control" name="numero" value="{{ $aluno->numero }}" />
          </div>

          <div class="form-group">
              <label for="nome">Bairro</label>
              <input type="text" class="form-control" name="bairro" value="{{ $aluno->bairro }}" />
          </div>

          <div class="form-group">
              <label for="cidade_id">Cidade</label>
              {{ Form::select('cidade_id', $cidades, $aluno->cidade_id, ["class"=>"form-control required", "id"=>"cidade_id", "name"=>"cidade_id"]) }}
          </div>

          <div class="form-group">
              <label for="nome">Cep</label>
              <input type="text" class="form-control" name="cep" value="{{ $aluno->cep }}" />
          </div>

          <div class="form-group">
              <label for="nome">E-mail</label>
              <input type="email" class="form-control" name="mail" value="{{ $aluno->mail }}" />
          </div>

          <input type="submit" class="btn btn-primary" value="Salvar"/>

          <a href="/alunos" class="btn btn-primary">Voltar</a>

@endsection
