<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name');
            $table->string('email')->unique();
            $table->string('password');
            $table->rememberToken();
            $table->timestamps();
        });

        DB::table('users')->insert(
            array(
              'name' => 'admin',
              'email' => 'admin@admin.com',
              'password' => '$2y$10$hLd1qOvyJ9iUlq1YCY/Z3O1KWHDaQU8NnZGi5.OAHMc58YakuTnqe', //admin1
              'tipo' => 1,
              'remember_token' => 'zU2YUxlr92erQ07Fss53EGs794yxJ3WG9FKS1wIHVedx6CNQimzOOgLevPHY'
            )
        );
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
