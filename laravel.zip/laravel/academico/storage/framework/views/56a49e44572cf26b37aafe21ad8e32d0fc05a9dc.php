<?php $__env->startSection('conteudo'); ?>

        <h1>Inserir cidade</h1>

        <form method="post" action="/cidades">

          <?php echo e(csrf_field()); ?>


          <div class="form-group">
              <label for="nome">Nome</label>
              <input type="text" class="form-control" name="nome" />
          </div>

          <div class="form-group">
              <label for="estado">Estado</label>
              <?php echo e(Form::select('estado_id', $estados, old('estado_id'), ["class"=>"form-control required", "id"=>"estado_id", "name"=>"estado_id"])); ?>

          </div>



          <input type="submit" class="btn btn-primary" value="Salvar"/>

          <a href="/estados" class="btn btn-primary">Voltar</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>