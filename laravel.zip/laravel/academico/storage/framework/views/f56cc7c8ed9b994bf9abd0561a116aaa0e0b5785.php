<?php $__env->startSection('conteudo'); ?>

        <h1>Exibir Aluno</h1>

        <form method="post" action="/alunos/<?php echo e($aluno->id); ?>">

          <?php echo e(method_field('DELETE')); ?>

          <?php echo e(csrf_field()); ?>


          Nome: <?php echo e($aluno->nome); ?><br>
          Rua: <?php echo e($aluno->rua); ?><br>
          Número: <?php echo e($aluno->numero); ?><br>
          Bairro: <?php echo e($aluno->bairro); ?><br>
          Cidade: <?php echo e($aluno->cidade->nome); ?> -  <?php echo e($aluno->cidade->estado->sigla); ?><br>
          Cep: <?php echo e($aluno->cep); ?><br>
          E-mail: <?php echo e($aluno->mail); ?><br>

          <br><br>

          <a href="/alunos/<?php echo e($aluno->id); ?>/edit" class="btn btn-primary">Editar</a>

          <input type="submit" class="btn btn-danger" value="Excluir"/>

          <a href="/alunos" class="btn btn-primary">Voltar</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>