<?php $__env->startSection('conteudo'); ?>

        <h1>Exibir disciplina</h1>

        <form method="post" action="/disciplinas/<?php echo e($disciplina->id); ?>">

          <?php echo e(method_field('DELETE')); ?>

          <?php echo e(csrf_field()); ?>


          Nome: <?php echo e($disciplina->nome); ?><br>
          Código: <?php echo e($disciplina->codigo); ?> <br>
          CH: <?php echo e($disciplina->carga); ?> <br>

          <br><br>

          <a href="/disciplinas/<?php echo e($disciplina->id); ?>/edit" class="btn btn-primary">Editar</a>

          <input type="submit" class="btn btn-danger" value="Excluir"/>

          <a href="/disciplinas" class="btn btn-primary">Voltar</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>