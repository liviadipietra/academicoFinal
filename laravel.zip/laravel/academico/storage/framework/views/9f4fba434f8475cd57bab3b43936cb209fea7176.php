<?php $__env->startSection('conteudo'); ?>

        <h1>Editar turma</h1>

        <form method="post" action="/turmas/<?php echo e($turma->id); ?>">

          <?php echo e(method_field('PATCH')); ?>

          <?php echo e(csrf_field()); ?>


          <div class="form-group">
              <label for="nome">Nome</label>
              <input type="text" class="form-control" name="nome" value="<?php echo e($turma->nome); ?>" />
          </div>

          <div class="form-group">
              <label for="disciplina">Disciplina</label>
              <?php echo e(Form::select('disciplina_id', $disciplinas, $turma->disciplina_id, ["class"=>"form-control required", "id"=>"disciplina_id", "name"=>"disciplina_id"])); ?>

          </div>

          <input type="submit" class="btn btn-primary" value="Salvar"/>

          <a href="/turmas" class="btn btn-primary">Voltar</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>