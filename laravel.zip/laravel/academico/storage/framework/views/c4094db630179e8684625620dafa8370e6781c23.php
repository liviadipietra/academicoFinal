<?php $__env->startSection('conteudo'); ?>

        <h1>Editar Aluno</h1>

        <form method="post" action="/alunos/<?php echo e($aluno->id); ?>">

          <?php echo e(method_field('PATCH')); ?>

          <?php echo e(csrf_field()); ?>


          <div class="form-group">
              <label for="nome">Nome</label>
              <input type="text" class="form-control" name="nome" value="<?php echo e($aluno->nome); ?>" />
          </div>

          <div class="form-group">
              <label for="nome">Rua</label>
              <input type="text" class="form-control" name="rua" value="<?php echo e($aluno->rua); ?>" />
          </div>

          <div class="form-group">
              <label for="nome">Número</label>
              <input type="number" class="form-control" name="numero" value="<?php echo e($aluno->numero); ?>" />
          </div>

          <div class="form-group">
              <label for="nome">Bairro</label>
              <input type="text" class="form-control" name="bairro" value="<?php echo e($aluno->bairro); ?>" />
          </div>

          <div class="form-group">
              <label for="cidade_id">Cidade</label>
              <?php echo e(Form::select('cidade_id', $cidades, $aluno->cidade_id, ["class"=>"form-control required", "id"=>"cidade_id", "name"=>"cidade_id"])); ?>

          </div>

          <div class="form-group">
              <label for="nome">Cep</label>
              <input type="text" class="form-control" name="cep" value="<?php echo e($aluno->cep); ?>" />
          </div>

          <div class="form-group">
              <label for="nome">E-mail</label>
              <input type="email" class="form-control" name="mail" value="<?php echo e($aluno->mail); ?>" />
          </div>

          <input type="submit" class="btn btn-primary" value="Salvar"/>

          <a href="/alunos" class="btn btn-primary">Voltar</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>