<?php $__env->startSection('conteudo'); ?>

        <h1>Exibir cidade</h1>

        <form method="post" action="/cidades/<?php echo e($cidade->id); ?>">

          <?php echo e(method_field('DELETE')); ?>

          <?php echo e(csrf_field()); ?>


          Nome: <?php echo e($cidade->nome); ?><br>
          Estado: <?php echo e($cidade->estado->sigla); ?> <br>

          <br><br>

          <a href="/cidades/<?php echo e($cidade->id); ?>/edit" class="btn btn-primary">Editar</a>

          <input type="submit" class="btn btn-danger" value="Excluir"/>

          <a href="/cidades" class="btn btn-primary">Voltar</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>