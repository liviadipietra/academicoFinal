<?php $__env->startSection('conteudo'); ?>

  <h2>Sobre o Sistema Acadêmico:</h2>
  <br><br><p>Sistema para controle acadêmico.</p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>