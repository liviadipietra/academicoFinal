<!DOCTYPE html>
<html lang="en">
    <head>
        <title>Sistema Acadêmico</title>
    </head>
    <body>

        <h1>Estados</h1>

        <?php $__currentLoopData = $estados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <?php echo e($e->nome); ?> <br>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    </body>
</html>