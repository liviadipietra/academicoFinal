<?php $__env->startSection('conteudo'); ?>

        <h1>Exibir estado</h1>

        <form method="post" action="/estados/<?php echo e($estado->id); ?>">

          <?php echo e(method_field('DELETE')); ?>

          <?php echo e(csrf_field()); ?>


          Nome: <?php echo e($estado->nome); ?><br>
          Sigla: <?php echo e($estado->sigla); ?> <br>

          <br><br>

          <a href="/estados/<?php echo e($estado->id); ?>/edit" class="btn btn-primary">Editar</a>

          <input type="submit" class="btn btn-danger" value="Excluir"/>

          <a href="/estados" class="btn btn-primary">Voltar</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>