<?php $__env->startSection('conteudo'); ?>

  <h2> Seja bem-vindo(a) ao Sistema Acadêmico!</h2>
  <p>Acesse as opções pelo menu lateral.</p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>