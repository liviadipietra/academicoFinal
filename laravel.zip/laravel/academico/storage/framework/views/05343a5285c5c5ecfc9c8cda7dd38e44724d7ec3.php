<?php $__env->startSection('conteudo'); ?>

        <h1>Editar estado</h1>

        <form method="post" action="/estados/<?php echo e($estado->id); ?>">

          <?php echo e(method_field('PATCH')); ?>

          <?php echo e(csrf_field()); ?>


          <div class="form-group">
              <label for="nome">Nome</label>
              <input type="text" class="form-control" name="nome" value="<?php echo e($estado->nome); ?>" />
          </div>

          <div class="form-group">
              <label for="sigla">Sigla</label>
              <input type="text" class="form-control" name="sigla" value="<?php echo e($estado->sigla); ?>" />
          </div>

          <input type="submit" class="btn btn-primary" value="Salvar"/>

          <a href="/estados" class="btn btn-primary">Voltar</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>