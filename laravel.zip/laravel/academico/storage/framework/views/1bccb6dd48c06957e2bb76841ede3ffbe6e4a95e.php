<?php $__env->startSection('conteudo'); ?>

        <h1>Exibir turma</h1>

        <form method="post" action="/turmas/<?php echo e($turma->id); ?>">

          <?php echo e(method_field('DELETE')); ?>

          <?php echo e(csrf_field()); ?>


          Nome: <?php echo e($turma->nome); ?><br>
          Disciplina: <?php echo e($turma->disciplina->nome); ?> <br>

          <br><br>

          <a href="/turmas/<?php echo e($turma->id); ?>/edit" class="btn btn-primary">Editar</a>

          <input type="submit" class="btn btn-danger" value="Excluir"/>

          <a href="/turmas" class="btn btn-primary">Voltar</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>