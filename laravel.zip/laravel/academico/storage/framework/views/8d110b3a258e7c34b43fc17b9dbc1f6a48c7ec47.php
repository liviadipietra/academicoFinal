<?php $__env->startSection('conteudo'); ?>

        <h1>Disciplinas</h1>

        <?php if(Session::has('nome')): ?>
          <h2><?php echo e(Session::get('nome')); ?></h2>
        <?php endif; ?>

  <a href="/disciplinas/create" class="btn btn-primary">Inserir</a>

  <table class="table table-striped">
    <thead>
      <tr>
        <th>Nome</th>
        <th>Código</th>
        <th>C.H</th>
      </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $disciplinas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <tr>

            <td><a href="/disciplinas/<?php echo e($d->id); ?>"><?php echo e($d->nome); ?></a></td>
            <td><?php echo e($d->codigo); ?></td>
            <td><?php echo e($d->carga); ?></td>

          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
  </table>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>